require('./scripts/gulpfile');
